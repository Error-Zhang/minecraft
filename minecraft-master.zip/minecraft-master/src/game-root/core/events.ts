import { EventEmitter } from "eventemitter3";

export const playerEvents = new EventEmitter();

export const interactEvents = new EventEmitter();
