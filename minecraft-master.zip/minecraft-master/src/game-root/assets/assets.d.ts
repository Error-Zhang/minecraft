declare module "*.gltf" {
	const src: string;
	export default src;
}
