namespace MineCraftService.Web;

public class Coord
{
    public int X { get; set; }
    public int Z { get; set; }
}