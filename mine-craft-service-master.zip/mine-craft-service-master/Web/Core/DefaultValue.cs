namespace MineCraftService.Web;

public static class DefaultValue
{
    public static readonly int Id = 0;
    public static readonly string String= string.Empty;
    public static readonly int Enum= -1;
}