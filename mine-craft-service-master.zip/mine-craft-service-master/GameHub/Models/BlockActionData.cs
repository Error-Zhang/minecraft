namespace MineCraftService.GameHub;

public class BlockActionData
{
    public int BlockId { get; set; }
    public int PlayerId { get; set; }
    public int X { get; set; }
    public int Y { get; set; }
    public int Z { get; set; }
}