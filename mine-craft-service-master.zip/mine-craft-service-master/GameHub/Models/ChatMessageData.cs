namespace MineCraftService.GameHub;

public class ChatMessageData
{
    public int PlayerId { get; set; }
    public string Message { get; set; } = string.Empty;
}