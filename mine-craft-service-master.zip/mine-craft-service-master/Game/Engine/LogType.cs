namespace Engine
{
	public enum LogType
	{
		Debug,
		Verbose,
		Information,
		Warning,
		Error
	}
}